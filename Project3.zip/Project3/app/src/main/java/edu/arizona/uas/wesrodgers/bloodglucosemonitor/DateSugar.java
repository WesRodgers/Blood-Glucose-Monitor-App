package edu.arizona.uas.wesrodgers.bloodglucosemonitor;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.UUID;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DateSugar#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DateSugar extends Fragment {
    //Don't forget to write getters/setters and change these back to private!!
    private int mDay, mMonth, mYear;
    public UUID id;
    public Date mDate;
    private TextView fastingNote, breakfastNote, lunchNote, dinnerNote, notes;
    private Button clearButton, historyButton;
    private CheckBox normalCheck;
    private TextView fastingNumber, breakfastNumber, lunchNumber, dinnerNumber;
    public int fasting, breakfast, lunch, dinner;
    public boolean fastingNormal, breakfastNormal, lunchNormal, dinnerNormal;
    public String noteString;
    private boolean populated = false;
    private boolean editable = false;

    public DateSugar() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     * @return A new instance of fragment DateSugar.
     */
    public static DateSugar newInstance() {
        DateSugar fragment = new DateSugar();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //if a save state was passed in, populate from that
        if(savedInstanceState != null){
            mDay = savedInstanceState.getInt("day");
            mMonth = savedInstanceState.getInt("month");
            mYear = savedInstanceState.getInt("year");
            mDate = new Date(mYear-1900, mMonth-1, mDay-0);
            noteString = savedInstanceState.getString("notes");
            fasting = savedInstanceState.getInt("fasting");
            breakfast = savedInstanceState.getInt("breakfast");
            lunch = savedInstanceState.getInt("lunch");
            dinner = savedInstanceState.getInt("dinner");
            id = (UUID) savedInstanceState.getSerializable("id");
            populated = true;
        }

        //otherwise, if populated then use that
        else if(!populated) {
            mDate = new Date();
            String tempdate = new SimpleDateFormat("dd MM yyyy").format(mDate);
            String[] dateArray = tempdate.split(" ");
            mDay = Integer.valueOf(dateArray[0]);
            mMonth = Integer.valueOf(dateArray[1]);
            mYear = Integer.valueOf(dateArray[2]);
            fasting = 0;
            breakfast = 0;
            lunch = 0;
            dinner = 0;
            fastingNormal = false;
            breakfastNormal = false;
            lunchNormal = false;
            dinnerNormal = false;
            id = UUID.randomUUID();
        }

        //make current date entry editable
        if(isToday(mDate)) unlock();
    }

    /**
     * Extracts the fields from a Sugar item and populates this object's fields
     * with the correct info
     * @param sugar
     */
    public void populateFromSugar(Sugar sugar){
        mDate = sugar.getDate();
        String tempDate = new SimpleDateFormat("dd MM yyyy").format(mDate);
        String[] dateArray = tempDate.split(" ");
        mDay = Integer.valueOf(dateArray[0]);
        mMonth = Integer.valueOf(dateArray[1]);
        mYear = Integer.valueOf(dateArray[2]);
        fasting = sugar.getFasting();
        breakfast = sugar.getBreakfast();
        lunch = sugar.getLunch();
        dinner = sugar.getDinner();
        noteString = sugar.getNote();
        populated = true;
        id = sugar.getId();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_date_sugar, container, false);

        Button dateField = (Button) v.findViewById(R.id.date);
        String month = new DateFormatSymbols().getMonths()[mMonth-1];
        dateField.setText(String.format("%d %s %d", mDay, month, mYear));

        fastingNote = v.findViewById(R.id.fastingNote);
        breakfastNote = v.findViewById(R.id.breakfastNote);
        lunchNote = v.findViewById(R.id.lunchNote);
        dinnerNote = v.findViewById(R.id.dinnerNote);
        clearButton = v.findViewById(R.id.clearButton);
        historyButton = v.findViewById(R.id.historyButton);
        normalCheck = v.findViewById(R.id.normalCheck);
        fastingNumber = v.findViewById(R.id.fastingLevel);
        breakfastNumber = v.findViewById(R.id.breakfastLevel);
        lunchNumber = v.findViewById(R.id.lunchLevel);
        dinnerNumber = v.findViewById(R.id.dinnerLevel);
        notes = v.findViewById(R.id.notes);

        //if this isn't an editable file, disable the textviews so they can't
        //be changed
        if(!editable){
            fastingNumber.setEnabled(false);
            breakfastNumber.setEnabled(false);
            lunchNumber.setEnabled(false);
            dinnerNumber.setEnabled(false);
            notes.setEnabled(false);
        }

        //if this was populated already, set the notes.
        if(populated){
            String sugarStatus = sugarStatus(fasting, true);
            fastingNormal = sugarStatus.equals("Normal") ? true : false;
            fastingNote.setText(String.format("[Fasting: %s]", sugarStatus));

            sugarStatus = sugarStatus(breakfast, false);
            breakfastNormal = sugarStatus.equals("Normal") ? true : false;
            breakfastNote.setText(String.format("[Breakfast: %s]", sugarStatus));

            sugarStatus = sugarStatus(lunch, false);
            lunchNormal = sugarStatus.equals("Normal") ? true : false;
            lunchNote.setText(String.format("[Lunch: %s]", sugarStatus));

            sugarStatus = sugarStatus(dinner, false);
            dinnerNormal = sugarStatus.equals("Normal") ? true : false;
            dinnerNote.setText(String.format("[Dinner: %s]", sugarStatus));

            fastingNumber.setText(String.valueOf(fasting));
            breakfastNumber.setText(String.valueOf(breakfast));
            lunchNumber.setText(String.valueOf(lunch));
            dinnerNumber.setText(String.valueOf(dinner));

            if(fasting == 0){
                fastingNote.setText("");
                fastingNumber.setText("");
                fastingNumber.setHint("mg/dL");
            }
            if(breakfast == 0){
                breakfastNote.setText("");
                breakfastNumber.setText("");
                breakfastNumber.setHint("mg/dL");
            }
            if(lunch == 0){
                lunchNote.setText("");
                lunchNumber.setText("");
                lunchNumber.setHint("mg/dL");
            }
            if(dinner == 0){
                dinnerNote.setText("");
                dinnerNumber.setText("");
                dinnerNumber.setHint("mg/dL");
            }

            setNormal();
            notes.setText(noteString);
        }
        populated = true;

        fastingNumber.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().equals("")){
                    fasting = 0;
                    return;
                }
                else fasting = Integer.parseInt(s.toString());
                String sugarStatus = sugarStatus(fasting, true);
                fastingNormal = sugarStatus.equals("Normal") ? true : false;
                fastingNote.setText(String.format("[Fasting: %s]", sugarStatus));
                setNormal();
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        breakfastNumber.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().equals("")){
                    breakfast = 0;
                    return;
                }
                else breakfast = Integer.parseInt(s.toString());
                String sugarStatus = sugarStatus(breakfast,false);
                breakfastNormal = sugarStatus.equals("Normal") ? true : false;
                breakfastNote.setText(String.format("[Breakfast: %s]", sugarStatus));
                setNormal();
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        lunchNumber.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().equals("")){
                    lunch = 0;
                    return;
                }
                else lunch = Integer.parseInt(s.toString());
                String sugarStatus = sugarStatus(lunch,false);
                lunchNormal = sugarStatus.equals("Normal") ? true : false;
                lunchNote.setText(String.format("[Lunch: %s]", sugarStatus));
                setNormal();
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        dinnerNumber.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().equals("")){
                    dinner = 0;
                    return;
                }
                else dinner = Integer.parseInt(s.toString());
                String sugarStatus = sugarStatus(dinner,false);
                dinnerNormal = sugarStatus.equals("Normal") ? true : false;
                dinnerNote.setText(String.format("[Dinner: %s]", sugarStatus));
                setNormal();
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        clearButton.setOnClickListener((e)->{
            if(!editable){
                return;
            }
            fastingNormal = false;
            fasting = 0;
            breakfastNormal = false;
            breakfast = 0;
            lunchNormal = false;
            lunch = 0;
            dinnerNormal = false;
            dinner = 0;
            fastingNote.setText("");
            fastingNumber.setText("");
            fastingNumber.setHint("mg/dL");
            breakfastNote.setText("");
            breakfastNumber.setText("");
            breakfastNumber.setHint("mg/dL");
            lunchNote.setText("");
            lunchNumber.setText("");
            lunchNumber.setHint("mg/dL");
            dinnerNote.setText("");
            dinnerNumber.setText("");
            dinnerNumber.setHint("mg/dL");
            notes.setText("");
            setNormal();

        });

        notes.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                noteString = String.valueOf(notes.getText());
            }
        });


        //if we are already on the current date, do nothing. Otherwise, search for a Sugar with
        //the current date and make a DateSugar fragment from it. If one doesn't exist, create a
        //completely new one.
        dateField.setOnClickListener((e)->{
            if(isToday(mDate)) return;
            SugarTests sTests = SugarTests.get(getActivity());
            Iterator<Sugar> s = sTests.getSugars().iterator();
            while(s.hasNext()){
                Sugar temp = s.next();
                if(isToday(temp.getDate())){
                    DateSugar sug = new DateSugar();
                    sug.populateFromSugar(temp);
                    Fragment historyFragment = sug;
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragmentContainer, historyFragment);
                    transaction.addToBackStack(null);
                    transaction.commit();
                    return;
                }
            }
            Fragment sug = new DateSugar();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainer, sug);
            transaction.addToBackStack(null);
            transaction.commit();

        });

        historyButton.setOnClickListener((e)->{
            Fragment historyFragment = new DateListFragment();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainer, historyFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        });
        return v;
    }

    private void setNormal() {
        normalCheck.setChecked(fastingNormal && breakfastNormal && lunchNormal && dinnerNormal);
    }

    public void lock(){
        editable = false;
    }

    public void unlock(){
        editable = true;
    }

    public String sugarStatus(int i, boolean fasted){
        if(i < 70) return "Hypoglycemic";
        if(fasted && i <= 99) return "Normal";
        if(fasted && i > 99) return "Abnormal";
        if(i < 140) return "Normal";
        return "Abnormal";
    }

    public boolean isToday(Date d){
        return d.getDay() == new Date().getDay()
                && d.getMonth() == new Date().getMonth()
                && d.getYear() == new Date().getYear();
    }

    //this makes sure to save the info into the sugarTests list when it is stopped
    @Override
    public void onStop(){
        super.onStop();
        SugarTests sTests = SugarTests.get(getActivity());
        Iterator<Sugar> s = sTests.getSugars().iterator();
        while(s.hasNext()){
            Sugar temp = s.next();
            if(temp.getId() == id) s.remove();
        }
        sTests.add(new Sugar(this));
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        savedInstanceState.putInt("fasting", fasting);
        savedInstanceState.putInt("breakfast", breakfast);
        savedInstanceState.putInt("lunch", lunch);
        savedInstanceState.putInt("dinner", dinner);
        savedInstanceState.putString("notes", noteString);
        savedInstanceState.putSerializable("id", id);
        savedInstanceState.putInt("day", mDay);
        savedInstanceState.putInt("month", mMonth);
        savedInstanceState.putInt("year", mYear);
    }

}
