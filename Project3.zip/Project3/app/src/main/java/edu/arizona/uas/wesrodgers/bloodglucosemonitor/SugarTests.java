package edu.arizona.uas.wesrodgers.bloodglucosemonitor;

import android.content.Context;
import android.support.v4.app.FragmentActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class SugarTests {
    private static SugarTests sSugarTests;

    public List<Sugar> mSugars;

    private SugarTests(Context context){
        mSugars = new ArrayList<>();
        for(int i=0; i<3; i++){
            Sugar sugar = new Sugar();
            sugar.setDate(new Date(119, 4, 28-i));
            sugar.setFasting(i+90);
            sugar.setBreakfast(i+90);
            sugar.setLunch(i+90);
            sugar.setDinner(i+90);
            sugar.setNote("");
            sugar.setSugar(i+90);
            sugar.setNormal(true);
            mSugars.add(sugar);
        }
    }

    public static SugarTests get(Context context) {
        if(sSugarTests == null){
            sSugarTests = new SugarTests(context);
        }

        return sSugarTests;
    }

    public static void sort() {
        Collections.sort(sSugarTests.mSugars, new SugarComparator());
    }

    private static class SugarComparator implements Comparator<Sugar>{
        @Override
        public int compare(Sugar o1, Sugar o2) {
            return o1.getDate().compareTo(o2.getDate());
        }
    }


    public List<Sugar> getSugars() {
        return mSugars;
    }

    public Sugar getSugar(UUID id){
        for(Sugar sugar : mSugars){
            if(sugar.getId().equals(id)) return sugar;
        }
        return null;
    }

    public static void add(Sugar sugar){
        sSugarTests.mSugars.add(sugar);
    }
}
