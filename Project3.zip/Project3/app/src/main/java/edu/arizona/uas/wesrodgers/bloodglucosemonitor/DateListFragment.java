package edu.arizona.uas.wesrodgers.bloodglucosemonitor;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.List;


/**
 * Fragment holding the recyclerView that lists historic Sugar data
 * @author Wes Rodgers
 */
public class DateListFragment extends Fragment {

    private RecyclerView mSugarRecyclerView;
    private SugarAdapter mAdapter;

    public DateListFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment DateListFragment.
     */
    public static DateListFragment newInstance() {
        DateListFragment fragment = new DateListFragment();
        return fragment;
    }


    /**
     * Inflates the view and sets up the recyclerView for the historic data
     * @param inflater a LayoutInflater
     * @param container the fragment container
     * @param savedInstanceState the Bundle of saved info
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_date_list, container, false);

        mSugarRecyclerView = (RecyclerView) v.findViewById(R.id.sugarRecyclerView);
        mSugarRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        updateUI();
        return v;
    }

    /**
     * grabs the SugarTests class data and sorts it, sets the adapter for the recycler view.
     */
    private void updateUI(){
        SugarTests sugarTests = SugarTests.get(getActivity());
        SugarTests.sort();
        List<Sugar> sugars = sugarTests.getSugars();
        mAdapter = new SugarAdapter(sugars);
        mSugarRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Private subclass to use as the fragment ViewHolder for the recyclerView's adapter
     */
    private class SugarHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private Sugar mSugar;
        private TextView mTitleTextView;
        private TextView mDateTextView;
        private CheckBox mNormalCheck;

        /**
         * Constructor for the holder, finds the appropriate fields for the
         * text and checkbox from the .xml layout file
         * @param inflater
         * @param parent
         */
        public SugarHolder(LayoutInflater inflater, ViewGroup parent){
            super(inflater.inflate(R.layout.list_item_sugar, parent, false));
            itemView.setOnClickListener(this);

            mTitleTextView = (TextView) itemView.findViewById(R.id.sugar_title);
            mDateTextView = (TextView) itemView.findViewById(R.id.sugar_date);
            mNormalCheck = (CheckBox) itemView.findViewById(R.id.sugar_check);
        }

        /**
         * Sets up the click listener for the historic data fragment
         * @param v passed in View
         */
        @Override
        public void onClick(View v) {
            DateSugar s = new DateSugar();
            s.populateFromSugar(mSugar);
            Fragment historyFragment = s;
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainer, historyFragment);
            transaction.addToBackStack(null);
            transaction.commit();

        }

        /**
         * Sets up the fragment to be displayed in the historic data
         * @param sugar the Sugar item we are setting up
         */
        public void bind(Sugar sugar) {
            mSugar = sugar;
            mTitleTextView.setText(String.valueOf(mSugar.getSugar()) + "   ");
            mDateTextView.setText("   " + new SimpleDateFormat("dd MMM yyyy")
                    .format(mSugar.getDate()));
            mNormalCheck.setChecked(mSugar.isNormal());
        }
    }

    /**
     * private subclass to act as an adapter for the recyclerView
     */
    private class SugarAdapter extends RecyclerView.Adapter<SugarHolder>{

        private List<Sugar> mSugars;
        public SugarAdapter(List<Sugar> sugars){ mSugars = sugars; }

        @Override
        public SugarHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new SugarHolder(layoutInflater, parent);
        }

        /**
         * Sets up SugarTests fragments when they are bound
         * @param sugarHolder the viewHolder for our recyclerView
         * @param i the index int
         */
        @Override
        public void onBindViewHolder(@NonNull SugarHolder sugarHolder, int i) {
            Sugar sugar = mSugars.get(i);
            sugarHolder.bind(sugar);
        }

        /**
         * getter for size of the historic data list
         * @return the number of items in the list
         */
        @Override
        public int getItemCount() {
            return mSugars.size();
        }
    }
}
